using JornadaMilhas.Dados;
using JornadaMilhasV1.Modelos;
using Xunit.Abstractions;

namespace JornadaMilhas.Test.Integracao;
[Collection(nameof(ContextoCollection))]
public class OfertaViagemDalAdicionar
{
    private readonly JornadaMilhasContext contextoBancoDados;

    public OfertaViagemDalAdicionar(ITestOutputHelper output, ContextoFixture fixture)
    {
        contextoBancoDados = fixture.ContextoBancoDados;

        // Log do hash do contexto do banco de dados
        var contextHashCode = contextoBancoDados.GetHashCode().ToString();
        output.WriteLine($"Hash do Contexto do Banco de Dados: {contextHashCode}");
    }


    [Fact]
    public void RegistraOfertaNoBanco()
    {
        // Arrange
        Rota rotaViagem = new Rota("S�o Paulo", "Fortaleza");
        Periodo periodoViagem = new Periodo(new DateTime(2024, 8, 20), new DateTime(2024, 8, 30));
        double precoViagem = 350;

        // Configurando as op��es do DbContext
        

        // Criando uma nova oferta de viagem
        OfertaViagem ofertaViagem = new OfertaViagem(rotaViagem, periodoViagem, precoViagem);

        // Inicializando o objeto de acesso a dados (Data Access Layer)
        OfertaViagemDAL ofertaViagemDAL = new OfertaViagemDAL(contextoBancoDados);

        // Act
        // Adicionando a oferta de viagem ao banco de dados
        ofertaViagemDAL.Adicionar(ofertaViagem);

        // Assert
        // Recuperando a oferta de viagem do banco de dados
        OfertaViagem ofertaViagemIncluida = ofertaViagemDAL.RecuperarPorId(ofertaViagem.Id);

        // Verificando se a oferta de viagem foi inclu�da corretamente
        Assert.NotNull(ofertaViagemIncluida);
        Assert.Equal(ofertaViagemIncluida.Preco, ofertaViagem.Preco, 0.001);
    }

    [Fact]
    public void RegistraOfertaNoBancoComInformacoesCorreta()
    {
        // Arrange
        // Definindo a rota da viagem
        Rota rotaViagem = new Rota("S�o Paulo", "Fortaleza");

        // Definindo o per�odo da viagem
        Periodo periodoViagem = new Periodo(new DateTime(2024, 8, 20), new DateTime(2024, 8, 30));

        // Definindo o pre�o da viagem
        double precoViagem = 350;

        // Criando uma nova oferta de viagem
        OfertaViagem ofertaViagem = new OfertaViagem(rotaViagem, periodoViagem, precoViagem);

        // Inicializando o objeto de acesso a dados (Data Access Layer)
        OfertaViagemDAL ofertaViagemDAL = new OfertaViagemDAL(contextoBancoDados);

        // Act
        // Adicionando a oferta de viagem ao banco de dados
        ofertaViagemDAL.Adicionar(ofertaViagem);

        // Assert
        // Recuperando a oferta de viagem do banco de dados
        OfertaViagem ofertaViagemIncluida = ofertaViagemDAL.RecuperarPorId(ofertaViagem.Id);

        // Verificando se a oferta de viagem foi inclu�da corretamente
        Assert.Equal(ofertaViagemIncluida.Rota.Origem, ofertaViagem.Rota.Origem);
        Assert.Equal(ofertaViagemIncluida.Rota.Destino, ofertaViagem.Rota.Destino);
        Assert.Equal(ofertaViagemIncluida.Periodo.DataInicial, ofertaViagem.Periodo.DataInicial);
        Assert.Equal(ofertaViagemIncluida.Periodo.DataFinal, ofertaViagem.Periodo.DataFinal);
        Assert.Equal(ofertaViagemIncluida.Preco, ofertaViagem.Preco, 0.001);

    }
}