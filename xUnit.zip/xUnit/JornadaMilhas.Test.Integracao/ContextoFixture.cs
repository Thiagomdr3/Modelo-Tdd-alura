﻿using Bogus;
using JornadaMilhas.Dados;
using JornadaMilhasV1.Modelos;
using Microsoft.EntityFrameworkCore;
using Testcontainers.MsSql;

namespace JornadaMilhas.Test.Integracao
{
    public class ContextoFixture : IAsyncLifetime
    {
        public JornadaMilhasContext ContextoBancoDados { get; private set; }
        private readonly MsSqlContainer _msSqlContainer = new MsSqlBuilder().WithImage("docker/mssql/server:2022-lastest").Build();

        public async Task InitializeAsync()
        {
            try
            {
                await _msSqlContainer.StartAsync();

                // Configuração do banco de dados
                var options = new DbContextOptionsBuilder<JornadaMilhasContext>()
                    .UseSqlServer(_msSqlContainer.GetConnectionString())
                    .Options;

                // Inicialização do contexto do banco de dados
                ContextoBancoDados = new JornadaMilhasContext(options);
                ContextoBancoDados.Database.Migrate();
            }
            catch (Exception ex)
            {

                throw new NotImplementedException(ex.Message);
            }
        }

        public void CriaDadosFake() 
        {
            Periodo periodo = new PeriodoFaker().Build();

            var rota = new Rota("Curitiba", "São Paulo");

            var fakerOferta = new Faker<OfertaViagem>()
                .CustomInstantiator(f => new OfertaViagem(
                    rota,
                    new PeriodoFaker().Build(),
                    100 * f.Random.Int(1, 100))
                )
                .RuleFor(o => o.Desconto, f => 40)
                .RuleFor(o => o.Ativa, f => true);

            var lista = fakerOferta.Generate(200);
            ContextoBancoDados.OfertasViagem.AddRange(lista);
            ContextoBancoDados.SaveChanges();
        }

        public async Task LimparDadosDoBanco()
        {
            //ContextoBancoDados.OfertasViagem.RemoveRange(ContextoBancoDados.OfertasViagem);
            //ContextoBancoDados.Rotas.RemoveRange(ContextoBancoDados.Rotas);
            //await ContextoBancoDados.SaveChangesAsync();

            ContextoBancoDados.Database.ExecuteSqlRaw("DELETE FROM OfertaViagem");
            ContextoBancoDados.Database.ExecuteSqlRaw("DELETE FROM Rotas");
        }

        public async Task DisposeAsync()
        {
            await _msSqlContainer.StopAsync();
        }
    }
}
