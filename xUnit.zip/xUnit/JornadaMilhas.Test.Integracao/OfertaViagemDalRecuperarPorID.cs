﻿using JornadaMilhas.Dados;
using Xunit.Abstractions;

namespace JornadaMilhas.Test.Integracao;
[Collection(nameof(ContextoCollection))]

public class OfertaViagemDalRecuperarPorID 
{
    private readonly JornadaMilhasContext _contextoBancoDados;

    public OfertaViagemDalRecuperarPorID(ITestOutputHelper output, ContextoFixture fixture)
    {
        _contextoBancoDados = fixture.ContextoBancoDados;

        // Log do hash do contexto do banco de dados
        var contextHashCode = _contextoBancoDados.GetHashCode().ToString();
        output.WriteLine($"Hash do Contexto do Banco de Dados: {contextHashCode}");
    }

    [Fact]
    public void TestaRetornoNuloQuandoIdInexistente()
    {
        // Arrange
        var dal = new OfertaViagemDAL(_contextoBancoDados);

        // Act
        var ofertaRecuperada = dal.RecuperarPorId(-2);

        // Assert
        Assert.Null(ofertaRecuperada);
    }
}


